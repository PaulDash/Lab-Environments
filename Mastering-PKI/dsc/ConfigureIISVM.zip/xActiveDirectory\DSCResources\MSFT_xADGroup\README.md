# Description

The xADGroup DSC resource will manage groups within Active Directory.
