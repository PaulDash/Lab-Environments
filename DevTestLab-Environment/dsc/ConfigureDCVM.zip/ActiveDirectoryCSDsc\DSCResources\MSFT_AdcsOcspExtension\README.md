# Description

This resource can be used to configure the OCSP URI extensions on the
Certificate Authority after the feature has been installed on the server.
Using this DSC Resource to configure an ADCS Certificate Authority assumes that
the `ADCS-Cert-Authority` feature has already been installed.
